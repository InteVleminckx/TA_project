#include "barcodewindow.h"
#include "ui_barcodewindow.h"
#include "mainwindow.h"`


BarcodeWindow::BarcodeWindow(QWidget *parent, MainWindow *main, string bestemmingNaam, string re) :
    QDialog(parent),
    ui(new Ui::BarcodeWindow)
{
    printedCode = re;
    ui->setupUi(this);

    this->setWindowTitle("Ticket generator");
    ui->BestemmingNaam->setText(QString::fromStdString(bestemmingNaam));
    parentWindow = parent;
    mainWindow = main;
    Maksim genBar;
    genBar.stringToBarcode(re);



    string path = QCoreApplication::applicationDirPath().toStdString() + "/BarcodeFotos/" + re;

    save_image(path + ".ini");
    QPixmap pix(QString::fromStdString(path + ".bmp"));
    pix = pix.scaled(ui->BarcodeFoto->size(),Qt::KeepAspectRatio);
    ui->BarcodeFoto->setPixmap(pix);

}

BarcodeWindow::~BarcodeWindow()
{
    delete ui;
}

void BarcodeWindow::on_pushButton_clicked()
{

    close();
    mainWindow->show();
    mainWindow->showBarcode(printedCode);

}


void BarcodeWindow::on_pushButton_2_clicked()
{
    close();
    parentWindow->show();
}

