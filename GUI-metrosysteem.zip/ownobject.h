#ifndef OWNOBJECT_H
#define OWNOBJECT_H

#include <string>

using namespace std;

class OwnObject
{
private:
    string fName;
public:
    OwnObject(const string name): fName(name) {}
    string getfName() const;
};

#endif // OWNOBJECT_H
