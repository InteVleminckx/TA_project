#ifndef GENERATETICKET_H
#define GENERATETICKET_H

#include <QDialog>
#include <iostream>
#include "Datastructuur.h"
#include "barcodewindow.h"
#include "Barcode.h"
#include "Bestemming.h"

class MainWindow;

using namespace std;

namespace Ui {
class GenerateTicket;
}

class GenerateTicket : public QDialog
{
    Q_OBJECT
    MainWindow* mainWindow;

public:
    explicit GenerateTicket(MainWindow *parent = nullptr);
    ~GenerateTicket();

private slots:
    void on_pushButton_clicked();

    void on_BackToMenu_clicked();

private:
    Ui::GenerateTicket *ui;
    BarcodeWindow* windowBarcode;
};

#endif // GENERATETICKET_H
