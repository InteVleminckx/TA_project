#ifndef THIRDWINDOW_H
#define THIRDWINDOW_H

#include <QDialog>
#include <QPixmap>

namespace Ui {
class ThirdWindow;
}

class ThirdWindow : public QDialog
{
    Q_OBJECT

public:
    explicit ThirdWindow(QWidget *parent = nullptr);
    ~ThirdWindow();
    Ui::ThirdWindow *ui;
    void setImage(const QPixmap &pix);

private slots:

};

#endif // THIRDWINDOW_H
