#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit_bestemmingNaam->setPlaceholderText("Bestemming");
    ui->lineEdit->setPlaceholderText("Bestemming");
    ui->lineEdit_2->setPlaceholderText("Bestemming");
    ui->lineEdit_3->setPlaceholderText("Bestemming");
    ui->lineEdit_barcode->setPlaceholderText("Barcode");
    ui->lineEdit_4->setPlaceholderText("RE (optioneel)");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Ticket_clicked()
{
    ticketWindow = new GenerateTicket(this);
    ui->label_4->setText("Ticket naar: ");
    hide();
    ticketWindow->show();
}

void MainWindow::on_pushButton_clicked()
{
    srand ((int)time(NULL));
    QString text = ui->lineEdit_3->text();
    string halte = text.toStdString();
    QString regex = ui->lineEdit_4->text();
    string RE = regex.toStdString();
    Maksim maks;
    Bestemming* newHalte = new Bestemming(halte,"");
    if (RE.empty()){
    string re = maks.generateRE(datastructure,timeBRZ, timeTFA, memoryBRZ, memoryTFA, *newHalte);
    newHalte->setRegex(re);
    }else{
        bool geldig = controleSysteem(RE, datastructure, timeBRZ, timeTFA, memoryBRZ, memoryTFA, *newHalte);
        if(geldig){
            ui->label_toevoeging->setText("Succesvol toegevoegd.");
            newHalte->setRegex(RE);
        }else{
            timeBRZ.pop_back();
            timeTFA.pop_back();
            memoryBRZ.pop_back();
            memoryTFA.pop_back();
            newHalte->setRegex(maks.generateRE(datastructure,timeBRZ, timeTFA, memoryBRZ, memoryTFA, *newHalte));
            ui->label_toevoeging->setText("RE was niet geldig. RE gegenereerd.");
        }
    }
    Node* node = new Node(*newHalte);
    bool inserted = datastructure.insert(node);
    ui->lcdNumber->display(datastructure.getSize());
    ui->lineEdit_3->clear();
    ui->lineEdit_4->clear();

    if(RE.empty()){
        if (inserted)
        {
            ui->label_toevoeging->setText("Succesvol toegevoegd.");
        }

        else
        {
            ui->label_toevoeging->setText("Niet succesvol toegevoegd.");
        }
    }


    vector<Bestemming*> bestemmingen;
    datastructure.inorderTraversal(bestemmingen);

    QString overzichtText;

    for (int i = 0; i < bestemmingen.size(); i++)
    {
        overzichtText.push_back(QString::fromStdString(bestemmingen[i]->getName()));
        overzichtText.push_back("\n");
    }

    ui->BestemmingenOverView->setText(overzichtText);
    ui->label_verwijderd->clear();

}

void MainWindow::on_pushButton_2_clicked()
{
    QString text = ui->lineEdit_2->text();
    string halte = text.toStdString();
    bool deleted = datastructure.deleteNode(halte);
    ui->lcdNumber->display(datastructure.getSize());
    ui->lineEdit_2->clear();

    vector<Bestemming*> bestemmingen;
    datastructure.inorderTraversal(bestemmingen);

    QString overzichtText;

    for (int i = 0; i < bestemmingen.size(); i++)
    {
        overzichtText.push_back(QString::fromStdString(bestemmingen[i]->getName()));
        overzichtText.push_back("\n");
    }

    ui->BestemmingenOverView->setText(overzichtText);

    if (deleted)
    {
        ui->label_verwijderd->setText("Succesvol verwijderd.");
    }

    else
    {
        ui->label_verwijderd->setText("Niet succesvol verwijderd.");
    }

    ui->label_toevoeging->clear();
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->bestemming->clear();
    const QString test = ui->lineEdit->text();
    std::string input = test.toStdString();

    // Bestemming opvragen
    pair<bool, Bestemming*> pair = datastructure.getBestemming(input);

    // Als bestemming gevonden is, geven we deze terug in de vorm van een label
    if (pair.first)
    {
        const QString found = QString::fromStdString(pair.second->getRegex());
        ui->bestemming->setText(found);
    }

    // Anders geven we "Bestemming niet gevonden" terug
    else
    {
        ui->bestemming->setText("Bestemming niet gevonden");
    }
    ui->lineEdit->clear();
}

void MainWindow::on_HTML_clicked()
{
    QDesktopServices::openUrl(QUrl("file:///" + QCoreApplication::applicationDirPath() + "/HTMLs/Speedcomparison.html"));
}

void MainWindow::on_HTML_2_clicked()
{
    QDesktopServices::openUrl(QUrl("file:///" + QCoreApplication::applicationDirPath() + "/HTMLs/Mermorycomparison.html"));
}


void MainWindow::on_HTML_3_clicked()
{
    Plotter time = Plotter(timeTFA, timeBRZ, "Speed");
    Plotter memeory = Plotter(memoryTFA, memoryBRZ, "Mermory");
}


void MainWindow::on_pushButton_4_clicked()
{
    datastructure.clearTree();
    timeBRZ.clear();
    timeTFA.clear();
    memoryBRZ.clear();
    memoryTFA.clear();
    ui->lcdNumber->display(datastructure.getSize());
    ui->lineEdit_2->clear();

    vector<Bestemming*> bestemmingen;
    datastructure.inorderTraversal(bestemmingen);

    QString overzichtText;

    for (int i = 0; i < bestemmingen.size(); i++)
    {
        overzichtText.push_back(QString::fromStdString(bestemmingen[i]->getName()));
        overzichtText.push_back("\n");
    }

    ui->BestemmingenOverView->setText(overzichtText);
    ui->BarcodeTicket->setText("No printed Ticket");
    ui->lineEdit_bestemmingNaam->clear();
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    ui->lineEdit_3->clear();
    ui->lineEdit_barcode->clear();
    ui->label_4->setText("Ticket naar: ");
    ui->bestemming->clear();
    ui->label_error_Random_Barcode->clear();
    ui->label_message_barcode_controllen->clear();
    ui->label_verwijderd->clear();
    ui->label_toevoeging->clear();


}


void MainWindow::on_pushButton_5_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open the file");


    if (!fileName.isEmpty())
    {
        string file_string = fileName.toStdString();
        Importer::readXMLFile(file_string, datastructure, timeBRZ, timeTFA, memoryBRZ, memoryTFA);
        ui->lcdNumber->display(datastructure.getSize());
        vector<Bestemming*> alle_best;
        datastructure.inorderTraversal(alle_best);

        QString overzichtText;

        for (int i = 0; i < alle_best.size(); i++)
        {
            overzichtText.push_back(QString::fromStdString(alle_best[i]->getName()));
            overzichtText.push_back("\n");
        }

        ui->BestemmingenOverView->setText(overzichtText);

    }
}


void MainWindow::on_pushButton_6_clicked()
{
    Maksim::createHTMLFile(datastructure);
    QDesktopServices::openUrl(QUrl("file:///" + QCoreApplication::applicationDirPath() + "/HTMLs/Table.html"));
}


void MainWindow::on_pushButton_Render_Barcode_clicked()
{

    string bestemmingNaam = ui->lineEdit_bestemmingNaam->text().toStdString();

    if (datastructure.getBestemming(bestemmingNaam).first)
    {
        string barcode = datastructure.getBestemming(bestemmingNaam).second->getBarcode();

        if (barcode.size() == 0)
        {
            ui->label_error_Random_Barcode->setText("Er is nog geen ticket gekocht voor deze bestemming.");
            ui->label_message_barcode_controllen->clear();
        }

        else
        {
            ui->lineEdit_barcode->setText(QString::fromStdString(barcode));
            ui->label_message_barcode_controllen->clear();
        }


    }

    else
    {
        ui->label_error_Random_Barcode->setText("Deze bestemming bestaat niet.");
        ui->label_message_barcode_controllen->clear();
    }


}


void MainWindow::on_pushButton_Controleer_barcode_clicked()
{

    string bestemmingNaam = ui->lineEdit_bestemmingNaam->text().toStdString();



    if (datastructure.getBestemming(bestemmingNaam).first)
    {
        string barcode = ui->lineEdit_barcode->text().toStdString();

        ui->lineEdit_barcode->setText("");


        DFA minDFA = datastructure.getBestemming(bestemmingNaam).second->getDFA();


        if (minDFA.accepts(barcode))
        {
            ui->label_message_barcode_controllen->setText("De barcode is aanvaardt voor de ingeven bestemming.");
            ui->label_error_Random_Barcode->clear();

            if  (ticketToScan == barcode)
            {
                ui->BarcodeTicket->setText("Buy a ticket");
                ui->label_4->setText("Ticket naar:");
            }

        }

        else
        {
            ui->label_message_barcode_controllen->setText("De barcode wordt niet aanvaardt voor de ingeven bestemming.");
            ui->label_error_Random_Barcode->clear();
        }
    }

    else
    {
        ui->label_error_Random_Barcode->setText("Geef eerst een geldige bestemming op voor je je barcode controlleert.");
    }

}


void MainWindow::showBarcode(string re){
    string path = QCoreApplication::applicationDirPath().toStdString() + "/BarcodeFotos/" + re;
    save_image(path + ".ini");
    QPixmap pix(QString::fromStdString(path + ".bmp"));
    pix = pix.scaled(ui->BarcodeTicket->size(),Qt::KeepAspectRatio);
    ui->BarcodeTicket->setPixmap(pix);
    ticketToScan = re;
}


void MainWindow::on_Scanner_clicked()
{
    vector<Bestemming*> bestemmingen;
    datastructure.inorderTraversal(bestemmingen);
    for(auto halte:bestemmingen){
        if(halte->getDFA().accepts(ticketToScan)){
            ui->label_4->setText("Ticket naar: " + QString::fromStdString(halte->getName()));
            ui->BarcodeTicket->setText("Buy a ticket");
            halte->deleteBarcode(ticketToScan);
            ticketToScan = "";
            return;
        }
    }
    ticketToScan = "";
    ui->BarcodeTicket->setText("Buy a ticket");
    ui->label_4->setText("Geen geldige ticket!");
}

