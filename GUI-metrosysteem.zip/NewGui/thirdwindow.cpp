#include "thirdwindow.h"
#include "ui_thirdwindow.h"

ThirdWindow::ThirdWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ThirdWindow)
{
    ui->setupUi(this);
}

ThirdWindow::~ThirdWindow()
{
    delete ui;
}

void ThirdWindow::setImage(const QPixmap &pix)
{
    int w = ui->picture->width();
    int h = ui->picture->height();
    ui->picture->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}
