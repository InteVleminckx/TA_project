#include "generateticket.h"
#include "ui_generateticket.h"
#include "mainwindow.h"


GenerateTicket::GenerateTicket(MainWindow *parent) :
   ui(new Ui::GenerateTicket)
{
    ui->setupUi(this);
    ui->lineEdit->setPlaceholderText("Bestemming");
    this->setWindowTitle("Destination picker");
    mainWindow = parent;

    QString overzichtText;



    vector<Bestemming*> bestemmingen;

    parent->datastructure.inorderTraversal(bestemmingen);

    for (int i = 0; i < bestemmingen.size(); i++)
    {

        overzichtText.push_back(QString::fromStdString(bestemmingen[i]->getName()));
        overzichtText.push_back("\n");

    }


    ui->BestemmingOverzicht->setText(overzichtText);

}

GenerateTicket::~GenerateTicket()
{
    delete ui;
}

void GenerateTicket::on_pushButton_clicked()
{

    string bestemming = ui->lineEdit->text().toStdString();



    if (mainWindow->datastructure.getBestemming(bestemming).first)
    {
        cout << "Er is een bestemming gevonden" << endl;
        ui->lineEdit->setText("");

        Barcode barcode;

        string re = barcode.createBarcode(mainWindow->datastructure.getBestemming(bestemming).second->getRegex());

        mainWindow->datastructure.getBestemming(bestemming).second->setBarcode(re);

        hide();
        windowBarcode = new BarcodeWindow(this, mainWindow, bestemming, re);
        windowBarcode->show();

    }

    else
    {
        cout << "Deze bestemming bestaat niet" << endl;
        ui->lineEdit->setText("");
    }


}


void GenerateTicket::on_BackToMenu_clicked()
{

    close();
    mainWindow->show();

}

