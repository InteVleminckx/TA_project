#ifndef BARCODEWINDOW_H
#define BARCODEWINDOW_H

#include <QDialog>
#include <iostream>
#include <Maksim.h>
#include "engine.h"
#include <QtCore>
#include <QtGui>

class MainWindow;

using namespace std;

namespace Ui {
class BarcodeWindow;
}

class BarcodeWindow : public QDialog
{
    Q_OBJECT

public:
    explicit BarcodeWindow(QWidget *parent = nullptr, MainWindow *main = nullptr, string BestemmingNaam = " ", string re = " ");
    ~BarcodeWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::BarcodeWindow *ui;
    QWidget* parentWindow;
    MainWindow* mainWindow;
    string printedCode;
};

#endif // BARCODEWINDOW_H
