//
// Created by Cem Tuncay on 09/05/2021.
//

#include "Dzhem.h"

bool controleSysteem(string& re, Datastructuur &bestemmingen, vector<long>& timeBrz, vector<long>& timeTFA,
                     vector<long>& memoryBrz, vector<long>& memoryTFA, Bestemming& best) {
    RE newRE = RE(re, 'e');
    DFA dfaRE = newRE.toDFA();
    dfaRE.renameStates();
    DFA dfaReTFA = DFA(dfaRE);
    Brzozowski::brzozowskiAlgorithm(dfaRE, timeBrz);
    dfaRE.getMemory(memoryBrz);

    ofstream json;
    json.open(QCoreApplication::applicationDirPath().toStdString() + "/JSON_files/controlesysteem.json");
    dfaReTFA.print(json);
    json.close();
    TFA* tfa = new TFA(QCoreApplication::applicationDirPath().toStdString() + "/JSON_files/controlesysteem.json");
    *tfa = tfa->minimize(timeTFA);
    dfaReTFA = tfa->toDFA();
    dfaReTFA.renameStates();
    dfaReTFA.getMemory(memoryTFA);

    vector<Bestemming*> haltes;
    bestemmingen.inorderTraversal(haltes);
    for (int i = 0; i<haltes.size(); i++){
        auto halte  = haltes.at(i);
        //Pruductautomaat van de twee met doorsnede van de accepterende staten.
        DFA doorsnede = DFA(dfaRE, halte->getDFA(), true);
        vector<string> statesDoornsede = doorsnede.getAllStates();
        for (auto state:statesDoornsede){ //Controle of de productautomaat met de doorsnede een accepterende staat bevat
            if(doorsnede.isStateAccepting(state)){
                return false;
            }
        }
    }
    best.setDFA(dfaRE);
    return true;
}
