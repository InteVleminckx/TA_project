#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QtGui>
#include <QMessageBox>
#include <string>
#include <iostream>
#include <QPixmap>
#include "secondwindow.h"
#include "thirdwindow.h"
#include "Datastructuur.h"
#include "Bestemming.h"
#include "Maksim.h"
#include <time.h>
#include <QTextBrowser>
#include <QFileDialog>
#include "Importer.h"
#include "generateticket.h"


using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Ui::MainWindow *ui;
    ThirdWindow *thirdWindow = new ThirdWindow(this);
    Datastructuur datastructure;
    GenerateTicket* ticketWindow;
    vector<long> timeBRZ;
    vector<long> timeTFA;
    vector<long> memoryBRZ;
    vector<long> memoryTFA;
    string ticketToScan;
    void showBarcode(string re);

private slots:

    void on_Ticket_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_HTML_clicked();

    void on_HTML_2_clicked();

    void on_HTML_3_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_Render_Barcode_clicked();

    void on_pushButton_Controleer_barcode_clicked();

    void on_Scanner_clicked();
};
#endif // MAINWINDOW_H
