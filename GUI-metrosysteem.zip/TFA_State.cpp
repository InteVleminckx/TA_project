//
// Created by inte on 11.03.21.
//

#include "TFA_State.h"

void TFA_State::addTransition(pair<string, string> &transtion){transitions.push_back(transtion);}